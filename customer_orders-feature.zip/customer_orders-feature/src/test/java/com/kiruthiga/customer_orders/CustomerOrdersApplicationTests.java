package com.kiruthiga.customer_orders;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerOrdersApplicationTests {

	@Test
	void contextLoads() {
	}

}
